// Čtečka novinek ve formátu Atom a RSS s podporou TLS
// Projekt ISA
// VUT FIT v Brno
//
// Autor: Pavel Hurdalek (xhurda01)
// Datum: 30.10.2022

#include "atom_parser.h"
#include "error_handling.h"
#include "rss_parser.h"
#include "ssl.h"

int main () {
    printf("Testuji\n");
    return 0;
}

// Konec souboru feedreader_tester.c